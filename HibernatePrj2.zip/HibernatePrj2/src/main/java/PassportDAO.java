

import java.util.List;
import java.util.Set;



public interface PassportDAO {
	void addPassport(Passport passport);
	void modifyPassport(Passport passport);
	void deletePassport(int passportNumber);
	Passport findPassport(int passportNumber);
	Set<Passport> findAllPassports(Passport passport);
}