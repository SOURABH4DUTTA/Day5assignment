import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name ="customer_tbl")
public class Customer {

	@Id
	@Column(name = "cust_id")
	private int customerId;
	
	@Column(name ="cust_name")
	private String custName;
	
	@Column(name ="cust_add")
	private String custEmailAddress;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "CustomerSubscriptionLink",
	 joinColumns = {@JoinColumn(name ="cid")},
	 inverseJoinColumns = {@JoinColumn(name ="sid")})
	
	
	
	Set<Subscription> subscriptions = new HashSet<Subscription>();
	
	
	
	
	public int getCustomerId() {
		return customerId;
	
	
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustEmailAddress() {
		return custEmailAddress;
	}
	public void setCustEmailAddress(String custEmailAddress) {
		this.custEmailAddress = custEmailAddress;
	}
	public Set<Subscription> getSubscriptions() {
		
		return subscriptions;
	}
	public void setSubscriptions(Set<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}
	
	
	
}
