import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;


public class CrudTestingManyToMany {

	EntityManagerFactory emf;
	EntityManager em ;
	
	public CrudTestingManyToMany() {
		System.out.println("CrudTestingManyToMany()....");
		
				System.out.println("Trying to read persistence.xml file...");
				
				//3
				this.emf = Persistence.createEntityManagerFactory("MyJPA");
				System.out.println("EntityManagerFactory created....");
				
				this.em = emf.createEntityManager();
				System.out.println("EntityManager created....");
	}
	
	

	@Test
	public void createCustomers() {
		
		Customer cust1 = new Customer();
		cust1.setCustomerId(123);
		cust1.setCustName("Jack");
		cust1.setCustEmailAddress("jack@gmail.com");
		
		Customer cust2 = new Customer();
		cust2.setCustomerId(223);
		cust2.setCustName("Jane");
		cust2.setCustEmailAddress("jane@gmail.com");
		
		Customer cust3 = new Customer();
		cust3.setCustomerId(323);
		cust3.setCustName("Jill");
		cust3.setCustEmailAddress("jill@gmail.com");
		
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(cust1);
			em.persist(cust2);
			em.persist(cust3);
		tx.commit();
	}
	
	@Test
	public void createSubscriptions() {
		
		Subscription sub1 = new 		Subscription ();
		sub1.setSubscriptionId(55);
		sub1.setSubscriptionName("Books");
		sub1.setSubscriptionTypes("3 months");
		
		Subscription sub2 = new 		Subscription ();
		sub2.setSubscriptionId(66);
		sub2.setSubscriptionName("CDs");
		sub2.setSubscriptionTypes("2 months");
		
		Subscription sub3 = new 		Subscription ();
		sub3.setSubscriptionId(77);
		sub3.setSubscriptionName("DVDs");
		sub3.setSubscriptionTypes("1 month");
		
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(sub1);
			em.persist(sub2);
			em.persist(sub3);
		tx.commit();
	}
	
	@Test
	public void addingSubscriptionsToExistingCustomer() {
		
		Customer cust = em.find(Customer.class, 323);
		
		Subscription sub1 = em.find(Subscription.class, 55);
		Subscription sub2 = em.find(Subscription.class, 66);
		Subscription sub3 = em.find(Subscription.class, 77);
		
		cust.getSubscriptions().add(sub1);
		cust.getSubscriptions().add(sub2);
		cust.getSubscriptions().add(sub3);
		
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.merge(cust);
		et.commit();
	}
	
	@Test
	public void showSubscriptionNameByCustomerId() {
		
		Customer cust = em.find(Customer.class, 323);
		
		System.out.println("Customer name : "+cust.getCustName());
		
		Set<Subscription> subs = cust.getSubscriptions();
		for (Subscription subscription : subs) {
			System.out.println("Subscription Name : "+subscription.getSubscriptionName());
			System.out.println("Subscription Type : "+subscription.getSubscriptionTypes());
		}
		
		
	}
	
}

//One Employee <--> One PanCard

//One Employee <-> many Address

//Many Employee <-> Many Projects


//inheritance strategies
/*
 * 						BankAccount
 * 							|acno name bal
 * 				-----------------------------------------------
 * 				|						|				|
 * 			SavingsAccount			CurrentAccount	CreditAccount
 * 			|rate					odlimit			credlimit
 * 	FixedDepositAccount
 * 		maturity
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */