import java.time.LocalDate;

import org.junit.Test;

public class Testing1 {
	
	PassportDAOImpl passportDao = new PassportDAOImpl();
	
	@Test
	public void addANewPassport()
	{
		Passport passport = new Passport();
		passport.setPassportNo(101);
		passport.setExpiryDate(LocalDate.of(2032, 10, 15));
		passport.setExpiryDate(LocalDate.of(2032, 10, 15));
	}
}
	
	