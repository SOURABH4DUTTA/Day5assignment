
public interface EmployeeDAO {

}
